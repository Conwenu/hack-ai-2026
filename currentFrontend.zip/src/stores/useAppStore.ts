import { create } from "zustand";
import type { AppPhase, Goal, ChatMessage, TimelineNavState, Branch } from "../types";

interface AppStore {
  phase: AppPhase;
  setPhase: (p: AppPhase) => void;

  currentGoal: Goal | null;
  setCurrentGoal: (g: Goal | null) => void;
  addBranch: (branch: Branch) => void;        // ← new

  messages: ChatMessage[];
  addMessage: (m: ChatMessage) => void;
  clearMessages: () => void;

  nav: TimelineNavState;
  setNav: (partial: Partial<TimelineNavState>) => void;
  goToStep: (index: number) => void;
  nextStep: () => void;
  prevStep: () => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  phase: "prompt",
  setPhase: (phase) => set({ phase }),

  currentGoal: null,
  setCurrentGoal: (currentGoal) =>
    set({
      currentGoal,
      nav: {
        currentStepIndex: 0,
        totalSteps: currentGoal?.steps.length ?? 0,
        isAnimating: false,
        zoomLevel: 1,
      },
    }),

  addBranch: (branch) => {
    const { currentGoal } = get();
    if (!currentGoal) return;

    // Mark the parent step with this branchId
    const steps = currentGoal.steps.map((s) =>
      s.id === branch.parentStepId ? { ...s, branchId: branch.id } : s
    );

    set({
      currentGoal: {
        ...currentGoal,
        steps,
        branches: [...currentGoal.branches, branch],
      },
    });
  },

  messages: [],
  addMessage: (m) => set((s) => ({ messages: [...s.messages, m] })),
  clearMessages: () => set({ messages: [] }),

  nav: { currentStepIndex: 0, totalSteps: 0, isAnimating: false, zoomLevel: 1 },
  setNav: (partial) => set((s) => ({ nav: { ...s.nav, ...partial } })),
  goToStep: (index) => {
    const { nav } = get();
    if (index >= 0 && index < nav.totalSteps) {
      set({ nav: { ...nav, currentStepIndex: index, isAnimating: true } });
    }
  },
  nextStep: () => {
    const { nav } = get();
    if (nav.currentStepIndex < nav.totalSteps - 1) {
      set({ nav: { ...nav, currentStepIndex: nav.currentStepIndex + 1, isAnimating: true } });
    }
  },
  prevStep: () => {
    const { nav } = get();
    if (nav.currentStepIndex > 0) {
      set({ nav: { ...nav, currentStepIndex: nav.currentStepIndex - 1, isAnimating: true } });
    }
  },
}));