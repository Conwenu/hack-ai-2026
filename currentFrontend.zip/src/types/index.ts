export interface TimelineStep {
  id: string;
  index: number;
  title: string;
  description: string;
  duration?: string;
  status: "pending" | "active" | "completed";
  branchId?: string;
  metadata?: Record<string, unknown>;
}

export interface Branch {
  id: string;
  parentStepId: string;
  reconnectStepId: string;   // ← new: which main step it merges back into
  label: string;
  steps: TimelineStep[];
}

export interface Goal {
  id: string;
  raw_prompt: string;
  refined_prompt: string;
  title: string;
  summary: string;
  steps: TimelineStep[];
  branches: Branch[];
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export type AppPhase = "prompt" | "refining" | "transitioning" | "timeline";

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface TimelineNavState {
  currentStepIndex: number;
  totalSteps: number;
  isAnimating: boolean;
  zoomLevel: number;
}