import { useMemo } from "react";
import { useAppStore } from "../../stores/useAppStore";
import { TIMELINE_Z_SPACING } from "../../animations/config";
import TimelineNode from "./TimelineNode";
import TimelineConnector from "./TimelineConnector";
import TimelineCamera from "./TimelineCamera";
import type { TimelineStep, Branch } from "../../types";

interface TimelineSceneProps {
  onNodeClick: (step: TimelineStep, isBranch?: boolean, branchId?: string) => void;
  modalOpen: boolean;
}

const BRANCH_X_OFFSET = 2.8;
const BRANCH_Z_SPACING = 2.2;

export default function TimelineScene({ onNodeClick, modalOpen }: TimelineSceneProps) {
  const { currentGoal, nav, goToStep } = useAppStore();
  const steps = currentGoal?.steps ?? [];
  const branches = currentGoal?.branches ?? [];

  const branchByParentIndex = useMemo(() => {
    const map = new Map<number, Branch>();
    for (const branch of branches) {
      const idx = steps.findIndex((s) => s.id === branch.parentStepId);
      if (idx !== -1) map.set(idx, branch);
    }
    return map;
  }, [branches, steps]);

  const extraZBefore = useMemo(() => {
    const extra = new Array(steps.length).fill(0);
    for (const [parentIdx, branch] of branchByParentIndex.entries()) {
      const reconnectIdx = steps.findIndex((s) => s.id === branch.reconnectStepId);
      if (reconnectIdx !== -1) {
        const branchHeight = branch.steps.length * BRANCH_Z_SPACING;
        const normalHeight = TIMELINE_Z_SPACING;
        const needed = Math.max(0, branchHeight - normalHeight);
        extra[reconnectIdx] += needed;
      }
    }
    return extra;
  }, [steps, branchByParentIndex]);

  const mainPositions = useMemo<[number, number, number][]>(() => {
    const positions: [number, number, number][] = [];
    let z = 0;
    for (let i = 0; i < steps.length; i++) {
      positions.push([0, 0, -z]);
      z += TIMELINE_Z_SPACING + (extraZBefore[i + 1] ?? 0);
    }
    return positions;
  }, [steps, extraZBefore]);

  const branchPositions = useMemo(() => {
    const result = new Map<string, [number, number, number][]>();
    for (const [parentIdx, branch] of branchByParentIndex.entries()) {
      const parentZ = mainPositions[parentIdx]?.[2] ?? 0;
      const positions: [number, number, number][] = branch.steps.map((_, i) => [
        BRANCH_X_OFFSET,
        0,
        parentZ - (i + 1) * BRANCH_Z_SPACING,
      ]);
      result.set(branch.id, positions);
    }
    return result;
  }, [branchByParentIndex, mainPositions]);

  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={0.8} />
      <pointLight position={[-5, -3, -10]} intensity={0.3} color="#4466ff" />

      <TimelineCamera activeIndex={nav.currentStepIndex} />

      {mainPositions.map((pos, i) => {
        if (i === mainPositions.length - 1) return null;
        return (
          <TimelineConnector
            key={`main-conn-${i}`}
            from={pos}
            to={mainPositions[i + 1]}
            active={i <= nav.currentStepIndex}
          />
        );
      })}

      {steps.map((step: TimelineStep, i: number) => (
        <TimelineNode
          key={step.id}
          step={step}
          position={mainPositions[i]}
          isActive={i === nav.currentStepIndex}
          modalOpen={modalOpen}
          isBranch={false}
          onClick={() => {
            goToStep(i);
            onNodeClick(step, false);
          }}
        />
      ))}

      {branches.map((branch) => {
        const parentIdx = steps.findIndex((s) => s.id === branch.parentStepId);
        const reconnectIdx = steps.findIndex((s) => s.id === branch.reconnectStepId);
        const bPositions = branchPositions.get(branch.id) ?? [];
        const parentPos = mainPositions[parentIdx];
        const reconnectPos = mainPositions[reconnectIdx];

        return (
          <group key={branch.id}>
            {parentPos && bPositions[0] && (
              <TimelineConnector
                from={parentPos}
                to={bPositions[0]}
                active={false}
                isBranchConnector
                isCurved={true}
              />
            )}

            {bPositions.map((pos, i) => {
              if (i === bPositions.length - 1) return null;
              return (
                <TimelineConnector
                  key={`b-conn-${i}`}
                  from={pos}
                  to={bPositions[i + 1]}
                  active={false}
                  isBranchConnector
                />
              );
            })}

            {bPositions.length > 0 && reconnectPos && (
              <TimelineConnector
                from={bPositions[bPositions.length - 1]}
                to={reconnectPos}
                active={false}
                isBranchConnector
                isCurved={true}
              />
            )}

            {branch.steps.map((step, i) => (
              <TimelineNode
                key={step.id}
                step={step}
                position={bPositions[i]}
                isActive={false}
                modalOpen={modalOpen}
                isBranch={true}
                onClick={() => onNodeClick(step, true, branch.id)}
              />
            ))}
          </group>
        );
      })}

      <fog attach="fog" args={["#000000", 15, 60]} />
    </>
  );
}