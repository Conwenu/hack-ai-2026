import type { ChatMessage } from "../../types";

interface ChatMessagesProps {
  messages: ChatMessage[];
}

export default function ChatMessages({ messages }: ChatMessagesProps) {
  if (messages.length === 0) return null;

  return (
    <div className="w-full max-w-2xl flex flex-col gap-3 mb-4 overflow-y-auto max-h-[40vh] px-1">
      {messages.map((msg) => (
        <div
          key={msg.id}
          className={`
            px-4 py-3 rounded-xl text-sm leading-relaxed font-body
            animate-fade-in
            ${
              msg.role === "user"
                ? "bg-white/[0.06] text-white/70 self-end ml-16"
                : "bg-white/[0.03] text-white/50 self-start mr-16 border border-white/[0.05]"
            }
          `}
        >
          {msg.content}
        </div>
      ))}
    </div>
  );
}
