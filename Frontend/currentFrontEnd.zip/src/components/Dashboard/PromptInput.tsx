import { useState, useRef, useEffect } from "react";

interface PromptInputProps {
  onSubmit: (text: string) => void;
  disabled?: boolean;
  placeholder?: string;
  compact?: boolean;
}

export default function PromptInput({
  onSubmit,
  disabled = false,
  placeholder = "What goal do you want to achieve?",
  compact = false,
}: PromptInputProps) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, compact ? 60 : 160) + "px";
  }, [value, compact]);

  const handleSubmit = () => {
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSubmit(trimmed);
    setValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div
      className={`
        w-full
        rounded-2xl border border-white/[0.08]
        bg-white/[0.03] backdrop-blur-md
        transition-all duration-500 ease-out
        ${compact ? "max-w-xl px-4 py-3" : "max-w-2xl px-5 py-4"}
        ${disabled ? "opacity-40 pointer-events-none" : ""}
      `}
    >
      <div className="flex items-end gap-3">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          rows={1}
          className={`
            flex-1 bg-transparent resize-none outline-none
            text-white/90 placeholder-white/25
            font-body leading-relaxed
            min-h-[28px]
            ${compact ? "text-sm" : "text-base"}
          `}
        />
        <button
          onClick={handleSubmit}
          disabled={!value.trim() || disabled}
          className={`
            shrink-0 px-4 py-2 rounded-xl text-sm font-medium font-body
            transition-all duration-200
            ${
              value.trim() && !disabled
                ? "bg-white/10 text-white/90 hover:bg-white/15 active:scale-95"
                : "bg-white/[0.03] text-white/15 cursor-not-allowed"
            }
          `}
        >
          Send
        </button>
      </div>
      {!compact && (
        <p className="text-[11px] text-white/15 mt-2 font-body">
          Shift + Enter for new line
        </p>
      )}
    </div>
  );
}
