// ============================================================
// Ripple – Dashboard Page
// ------------------------------------------------------------
// Layout transitions:
// 1. "prompt" phase: Title centered, input centered, faint
//    timeline preview in background
// 2. "refining": Chat appears, input stays centered
// 3. "transitioning": Title slides to top-left, input slides
//    to bottom, timeline becomes the focus
// 4. "timeline": Full 3D timeline with HUD
// ============================================================

import { useAppStore } from "../stores/useAppStore";
import { generateMockGoal, generateMockRefinement } from "../services/mockData";
import { v4 } from "../utils/uid";
import PromptInput from "../components/Dashboard/PromptInput";
import ChatMessages from "../components/Dashboard/ChatMessages";
import TimelinePreview from "../components/Timeline/TimelinePreview";

export default function DashboardPage() {
  const { phase, messages, addMessage, setPhase, setCurrentGoal } =
    useAppStore();

  const isActive = phase === "prompt" || phase === "refining";
  const isTransitioning = phase === "transitioning";

  // Determine layout positions based on phase
  const titleInCenter = phase === "prompt" && messages.length === 0;
  const titleInTopLeft = isTransitioning || phase === "timeline";
  const inputAtBottom = isTransitioning || phase === "timeline";

  const handleSubmit = async (text: string) => {
    addMessage({
      id: v4(),
      role: "user",
      content: text,
      timestamp: new Date().toISOString(),
    });

    if (phase === "prompt") {
      setPhase("refining");

      // TODO (backend): Replace with submitGoal(text) from services/api.ts
      const mockReply = generateMockRefinement(text);
      setTimeout(() => addMessage(mockReply), 600);

      // Simulate backend deciding goal is ready
      setTimeout(() => {
        const goal = generateMockGoal(text);
        setCurrentGoal(goal);
        setPhase("transitioning");
        setTimeout(() => setPhase("timeline"), 1400);
      }, 2200);
    } else if (phase === "refining") {
      // TODO (backend): call refineGoal(goalId, text)
      const mockReply = generateMockRefinement(text);
      setTimeout(() => addMessage(mockReply), 500);
    }
  };

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      {/* Background: faint timeline preview extending into screen */}
      <TimelinePreview visible={phase === "prompt" || phase === "refining"} />

      {/* ---- Title: "Ripple" ---- */}
      <div
        className={`
          absolute z-20 transition-all duration-[1200ms] ease-[cubic-bezier(0.4,0,0.2,1)]
          ${
            titleInCenter
              ? "top-1/2 left-1/2 -translate-x-1/2 -translate-y-[120px]"
              : titleInTopLeft
              ? "top-6 left-8 translate-x-0 translate-y-0"
              : "top-1/2 left-1/2 -translate-x-1/2 -translate-y-[120px]"
          }
        `}
      >
        <h1
          className={`
            font-title text-white/90 leading-none
            transition-all duration-[1200ms]
            ${titleInCenter ? "text-6xl" : titleInTopLeft ? "text-2xl" : "text-5xl"}
          `}
        >
          Ripple
        </h1>
        {titleInCenter && (
          <p className="text-sm text-white/25 font-body mt-3 text-center animate-fade-in">
            Describe a goal. We'll map the path.
          </p>
        )}
      </div>

      {/* ---- Chat messages (center area) ---- */}
      {messages.length > 0 && !isTransitioning && phase !== "timeline" && (
        <div className="absolute z-20 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full px-4 flex flex-col items-center">
          <ChatMessages messages={messages} />
        </div>
      )}

      {/* ---- Prompt Input ---- */}
      <div
        className={`
          absolute z-20 left-1/2 -translate-x-1/2 w-full px-4
          flex justify-center
          transition-all duration-[1200ms] ease-[cubic-bezier(0.4,0,0.2,1)]
          ${
            inputAtBottom
              ? "bottom-6"
              : titleInCenter
              ? "top-1/2 translate-y-[20px]"
              : "top-1/2 translate-y-[60px]"
          }
        `}
      >
        <PromptInput
          onSubmit={handleSubmit}
          disabled={isTransitioning}
          compact={inputAtBottom}
          placeholder={
            phase === "refining"
              ? "Add more detail or say 'looks good'..."
              : "What goal do you want to achieve?"
          }
        />
      </div>
    </div>
  );
}
